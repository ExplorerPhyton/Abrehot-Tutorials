const express = require('express');
const { protect, restrictTo } = require('../middleware/auth');
const upload = require('../middleware/upload');
const {
  applyAsTutor,
  getMyApplication,
  getAllApplications,
  reviewApplication,
  listApprovedTutors,
} = require('../controllers/tutorController');

const router = express.Router();

// Public
router.get('/', listApprovedTutors);

// Logged-in users
router.post('/apply', protect, upload.single('certificate'), applyAsTutor);
router.get('/applications/mine', protect, getMyApplication);

// Admin only
router.get('/applications', protect, restrictTo('Admin'), getAllApplications);
router.patch('/applications/:id', protect, restrictTo('Admin'), reviewApplication);

module.exports = router;
