const express = require('express');
const { optionalAuth } = require('../middleware/auth');
const { submitContact } = require('../controllers/contactController');

const router = express.Router();

router.post('/', optionalAuth, submitContact);

module.exports = router;
