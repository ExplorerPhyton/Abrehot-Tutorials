const express = require('express');
const { protect } = require('../middleware/auth');
const { updateProfile, changePassword } = require('../controllers/profileController');

const router = express.Router();

router.use(protect);

router.patch('/', updateProfile);
router.post('/change-password', changePassword);

module.exports = router;
