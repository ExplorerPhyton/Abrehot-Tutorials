const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema(
  {
    fullName: { type: String, required: true, trim: true },
    email: {
      type: String,
      required: true,
      unique: true,
      lowercase: true,
      trim: true,
    },
    password: { type: String, required: true, minlength: 6, select: false },
    role: {
      type: String,
      enum: ['Parent', 'Student', 'Tutor', 'Admin'],
      required: true,
    },
    phone: { type: String, trim: true },
    profilePicture: { type: String, default: '' },

    // Password reset
    resetPasswordToken: { type: String, select: false },
    resetPasswordExpires: { type: Date, select: false },

    // Tutor-specific fields, filled in when a tutor application is approved
    tutorProfile: {
      approved: { type: Boolean, default: false },
      subjects: [String],
      grades: [String],
      languages: [String],
      mode: { type: String, enum: ['Online', 'In-Person', 'Both'] },
      city: String,
      address: String,
      price: Number,
      bio: String,
      availability: String,
      certificateUrl: String,
    },
  },
  { timestamps: true }
);

userSchema.pre('save', async function hashPassword(next) {
  if (!this.isModified('password')) return next();
  const salt = await bcrypt.genSalt(10);
  this.password = await bcrypt.hash(this.password, salt);
  next();
});

userSchema.methods.comparePassword = function comparePassword(candidate) {
  return bcrypt.compare(candidate, this.password);
};

userSchema.methods.toSafeObject = function toSafeObject() {
  const obj = this.toObject();
  delete obj.password;
  delete obj.resetPasswordToken;
  delete obj.resetPasswordExpires;
  return obj;
};

module.exports = mongoose.model('User', userSchema);
