const mongoose = require('mongoose');

const donationSchema = new mongoose.Schema(
  {
    donor: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }, // optional, donations can be anonymous
    donorName: String,
    donorEmail: String,

    amount: { type: Number, required: true },
    paymentMethod: {
      type: String,
      enum: ['telebirr', 'cbe'],
      required: true,
    },

    // Donor-submitted proof of payment, since Telebirr/CBE require manual
    // verification until a merchant API agreement is in place.
    transactionRef: { type: String, required: true },

    status: {
      type: String,
      enum: ['pending', 'verified', 'rejected'],
      default: 'pending',
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Donation', donationSchema);
