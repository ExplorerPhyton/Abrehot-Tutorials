const Donation = require('../models/Donation');

// GET /api/donations/payment-info
// Returns the account/merchant details to show on the donate page for the chosen method
function getPaymentInfo(req, res) {
  const { method } = req.query;

  const info = {
    telebirr: {
      label: 'Telebirr',
      merchantNumber: process.env.TELEBIRR_MERCHANT_NUMBER,
      instructions: 'Send your donation to this Telebirr number, then enter the transaction reference below.',
    },
    cbe: {
      label: 'Commercial Bank of Ethiopia',
      accountNumber: process.env.CBE_ACCOUNT_NUMBER,
      accountName: process.env.CBE_ACCOUNT_NAME,
      instructions: 'Transfer your donation to this CBE account, then enter the transaction reference below.',
    },
  };

  if (method && !info[method]) {
    return res.status(400).json({ message: 'Unsupported payment method.' });
  }

  res.json(method ? info[method] : info);
}

// POST /api/donations  (donate.html form)
async function submitDonation(req, res) {
  try {
    const { amount, customAmount, payment, transactionRef, donorName, donorEmail } = req.body;

    const finalAmount = Number(amount === 'other' ? customAmount : amount);
    if (!finalAmount || finalAmount <= 0) {
      return res.status(400).json({ message: 'Please provide a valid donation amount.' });
    }
    if (!['telebirr', 'cbe'].includes(payment)) {
      return res.status(400).json({ message: 'Please select a supported payment method.' });
    }
    if (!transactionRef) {
      return res.status(400).json({ message: 'Please enter your transaction reference after paying.' });
    }

    const donation = await Donation.create({
      donor: req.user ? req.user._id : undefined,
      donorName: donorName || (req.user ? req.user.fullName : 'Anonymous'),
      donorEmail: donorEmail || (req.user ? req.user.email : undefined),
      amount: finalAmount,
      paymentMethod: payment,
      transactionRef,
    });

    res.status(201).json({
      message: 'Thank you! Your donation is recorded and pending verification.',
      donation,
    });
  } catch (err) {
    res.status(500).json({ message: 'Could not record donation.', error: err.message });
  }
}

module.exports = { getPaymentInfo, submitDonation };
