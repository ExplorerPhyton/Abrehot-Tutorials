const Contact = require('../models/Contact');

// POST /api/contact
async function submitContact(req, res) {
  try {
    const { name, email, subject, message, rating, feedback } = req.body;

    if (!email || (!message && !feedback)) {
      return res.status(400).json({ message: 'Email and a message or feedback are required.' });
    }

    const contact = await Contact.create({
      user: req.user ? req.user._id : undefined,
      name,
      email,
      subject,
      message,
      rating,
      feedback,
    });

    res.status(201).json({ message: 'Thanks for reaching out! We will get back to you soon.', contact });
  } catch (err) {
    res.status(500).json({ message: 'Could not submit your message.', error: err.message });
  }
}

module.exports = { submitContact };
