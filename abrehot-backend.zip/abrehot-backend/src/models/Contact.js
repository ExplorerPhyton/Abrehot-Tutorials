const mongoose = require('mongoose');

const contactSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }, // optional, in case sender wasn't logged in
    name: String,
    email: String,
    subject: String,
    message: String,
    rating: { type: String, enum: ['Excellent', 'Good', 'Average', 'Poor'] },
    feedback: String,
    resolved: { type: Boolean, default: false },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Contact', contactSchema);
