const crypto = require('crypto');
const validator = require('validator');
const User = require('../models/User');
const generateToken = require('../utils/generateToken');
const sendEmail = require('../utils/sendEmail');

// POST /api/auth/signup
async function signup(req, res) {
  try {
    const { fullName, email, password, role, phone } = req.body;

    if (!fullName || !email || !password || !role) {
      return res.status(400).json({ message: 'Full name, email, password, and role are required.' });
    }
    if (!validator.isEmail(email)) {
      return res.status(400).json({ message: 'Please provide a valid email address.' });
    }
    if (password.length < 6) {
      return res.status(400).json({ message: 'Password must be at least 6 characters.' });
    }
    if (!['Parent', 'Student', 'Tutor'].includes(role)) {
      return res.status(400).json({ message: 'Invalid role.' });
    }

    const existing = await User.findOne({ email: email.toLowerCase() });
    if (existing) {
      return res.status(409).json({ message: 'An account with this email already exists.' });
    }

    const user = await User.create({ fullName, email, password, role, phone });
    const token = generateToken(user);

    res.status(201).json({ token, user: user.toSafeObject() });
  } catch (err) {
    res.status(500).json({ message: 'Something went wrong while creating your account.', error: err.message });
  }
}

// POST /api/auth/login
async function login(req, res) {
  try {
    const { email, password, role } = req.body;

    if (!email || !password) {
      return res.status(400).json({ message: 'Email and password are required.' });
    }

    const user = await User.findOne({ email: email.toLowerCase() }).select('+password');
    if (!user) {
      return res.status(401).json({ message: 'Invalid email or password.' });
    }

    // If the login form specifies a role (Parent/Student/Tutor), make sure it matches
    if (role && user.role !== role) {
      return res.status(401).json({ message: `No ${role.toLowerCase()} account found with these credentials.` });
    }

    const isMatch = await user.comparePassword(password);
    if (!isMatch) {
      return res.status(401).json({ message: 'Invalid email or password.' });
    }

    const token = generateToken(user);
    res.json({ token, user: user.toSafeObject() });
  } catch (err) {
    res.status(500).json({ message: 'Something went wrong while logging in.', error: err.message });
  }
}

// GET /api/auth/me
async function getMe(req, res) {
  res.json({ user: req.user.toSafeObject() });
}

// POST /api/auth/forgot-password
async function forgotPassword(req, res) {
  try {
    const { email } = req.body;
    if (!email) return res.status(400).json({ message: 'Email is required.' });

    const user = await User.findOne({ email: email.toLowerCase() });

    // Always respond the same way whether or not the user exists, to avoid leaking which emails are registered
    const genericResponse = { message: 'If an account with that email exists, a reset link has been sent.' };
    if (!user) return res.json(genericResponse);

    const rawToken = crypto.randomBytes(32).toString('hex');
    user.resetPasswordToken = crypto.createHash('sha256').update(rawToken).digest('hex');
    user.resetPasswordExpires = Date.now() + (Number(process.env.RESET_TOKEN_EXPIRES_MIN) || 30) * 60 * 1000;
    await user.save();

    const resetUrl = `${req.headers.origin || ''}/reset-password.html?token=${rawToken}`;

    try {
      await sendEmail({
        to: user.email,
        subject: 'Reset your Abrehot Online Tutorials password',
        html: `<p>You requested a password reset. This link expires in ${process.env.RESET_TOKEN_EXPIRES_MIN || 30} minutes.</p>
               <p><a href="${resetUrl}">Reset your password</a></p>
               <p>If you didn't request this, you can ignore this email.</p>`,
      });
    } catch (emailErr) {
      // Don't fail the request just because email sending failed in dev - log it instead
      console.error('Failed to send reset email:', emailErr.message);
    }

    res.json(genericResponse);
  } catch (err) {
    res.status(500).json({ message: 'Something went wrong.', error: err.message });
  }
}

// POST /api/auth/reset-password
async function resetPassword(req, res) {
  try {
    const { token, newPassword } = req.body;
    if (!token || !newPassword) {
      return res.status(400).json({ message: 'Token and new password are required.' });
    }
    if (newPassword.length < 6) {
      return res.status(400).json({ message: 'Password must be at least 6 characters.' });
    }

    const hashedToken = crypto.createHash('sha256').update(token).digest('hex');
    const user = await User.findOne({
      resetPasswordToken: hashedToken,
      resetPasswordExpires: { $gt: Date.now() },
    }).select('+resetPasswordToken +resetPasswordExpires');

    if (!user) {
      return res.status(400).json({ message: 'This reset link is invalid or has expired.' });
    }

    user.password = newPassword;
    user.resetPasswordToken = undefined;
    user.resetPasswordExpires = undefined;
    await user.save();

    res.json({ message: 'Your password has been reset. You can now log in.' });
  } catch (err) {
    res.status(500).json({ message: 'Something went wrong.', error: err.message });
  }
}

module.exports = { signup, login, getMe, forgotPassword, resetPassword };
