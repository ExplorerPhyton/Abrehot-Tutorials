const mongoose = require('mongoose');

const bookingSchema = new mongoose.Schema(
  {
    requestedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    tutor: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }, // set once matched/assigned

    grade: { type: String, required: true },
    subjects: [{ type: String }],
    topic: String,
    goals: [{ type: String }],

    sessionType: { type: String, enum: ['online', 'in-person'] },
    platform: {
      type: String,
      enum: ['googleMeet', 'zoom', 'microsoftTeams', 'telegram'],
    },
    city: String,
    address: String,
    language: String,

    date: Date,
    time: String,
    duration: String,
    notes: String,

    status: {
      type: String,
      enum: ['pending', 'confirmed', 'completed', 'cancelled'],
      default: 'pending',
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Booking', bookingSchema);
