const express = require('express');
const { protect } = require('../middleware/auth');
const {
  createBooking,
  getMyBookings,
  getAssignedBookings,
  updateBookingStatus,
} = require('../controllers/bookingController');

const router = express.Router();

router.use(protect); // all booking routes require login

router.post('/', createBooking);
router.get('/mine', getMyBookings);
router.get('/assigned', getAssignedBookings);
router.patch('/:id/status', updateBookingStatus);

module.exports = router;
