const Booking = require('../models/Booking');

// POST /api/bookings  (book.html form)
async function createBooking(req, res) {
  try {
    const {
      grade, subject, topic, goal,
      session, platform, city, address, language,
      date, time, duration, notes,
    } = req.body;

    if (!grade) {
      return res.status(400).json({ message: 'Grade is required.' });
    }

    const booking = await Booking.create({
      requestedBy: req.user._id,
      grade,
      subjects: Array.isArray(subject) ? subject : subject ? [subject] : [],
      topic,
      goals: Array.isArray(goal) ? goal : goal ? [goal] : [],
      sessionType: session,
      platform,
      city,
      address,
      language,
      date,
      time,
      duration,
      notes,
    });

    res.status(201).json({ message: 'Booking request submitted.', booking });
  } catch (err) {
    res.status(500).json({ message: 'Could not create booking.', error: err.message });
  }
}

// GET /api/bookings/mine (for student/parent dashboard)
async function getMyBookings(req, res) {
  const bookings = await Booking.find({ requestedBy: req.user._id })
    .populate('tutor', 'fullName email tutorProfile.subjects')
    .sort('-createdAt');
  res.json({ bookings });
}

// GET /api/bookings/assigned (for tutor dashboard)
async function getAssignedBookings(req, res) {
  const bookings = await Booking.find({ tutor: req.user._id }).sort('-createdAt');
  res.json({ bookings });
}

// PATCH /api/bookings/:id/status
async function updateBookingStatus(req, res) {
  try {
    const { status } = req.body;
    if (!['pending', 'confirmed', 'completed', 'cancelled'].includes(status)) {
      return res.status(400).json({ message: 'Invalid status.' });
    }

    const booking = await Booking.findById(req.params.id);
    if (!booking) return res.status(404).json({ message: 'Booking not found.' });

    const isOwner = booking.requestedBy.equals(req.user._id);
    const isAssignedTutor = booking.tutor && booking.tutor.equals(req.user._id);
    if (!isOwner && !isAssignedTutor && req.user.role !== 'Admin') {
      return res.status(403).json({ message: 'You cannot update this booking.' });
    }

    booking.status = status;
    await booking.save();
    res.json({ message: 'Booking updated.', booking });
  } catch (err) {
    res.status(500).json({ message: 'Could not update booking.', error: err.message });
  }
}

module.exports = { createBooking, getMyBookings, getAssignedBookings, updateBookingStatus };
