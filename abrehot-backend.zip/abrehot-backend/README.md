# Abrehot Online Tutorials — Backend API

Node.js + Express + MongoDB backend for the Abrehot Online Tutorials frontend.

## Features implemented
- Auth: signup, login, get current user, forgot/reset password (JWT-based)
- Bookings: create, view mine, view assigned (tutor), update status
- Tutor applications: apply (with certificate file upload), admin review/approve, public tutor listing
- Contact/feedback form submissions
- Donations: Telebirr/CBE manual-verification flow (donor submits transaction ref, admin verifies later)
- Profile: update info, change password

## Setup

1. Install dependencies:
   ```bash
   npm install
   ```

2. Copy the environment template and fill in real values:
   ```bash
   cp .env.example .env
   ```
   You need at minimum: `MONGO_URI` (from MongoDB Atlas) and `JWT_SECRET` (any long random string).
   Email (SMTP_*) is only needed for the "forgot password" email — safe to leave blank while testing other features.

3. Run in development (auto-restarts on changes):
   ```bash
   npm run dev
   ```
   Or for a normal run:
   ```bash
   npm start
   ```

4. Confirm it's alive: visit `http://localhost:5000/api/health` — should return `{"status":"ok"}`.

## Deploying (Render, free tier)
1. Push this folder to its own GitHub repo.
2. On [render.com](https://render.com): New → Web Service → connect the repo.
3. Build command: `npm install` — Start command: `npm start`.
4. Add all the variables from `.env` in Render's Environment settings.
5. Once deployed, update `CLIENT_ORIGINS` to include your live frontend's URL, and update the frontend's API base URL to point at the Render URL.

## API Overview

| Method | Endpoint | Auth | Purpose |
|---|---|---|---|
| POST | /api/auth/signup | — | Create account |
| POST | /api/auth/login | — | Log in |
| GET | /api/auth/me | required | Get current user |
| POST | /api/auth/forgot-password | — | Request reset email |
| POST | /api/auth/reset-password | — | Reset with token |
| POST | /api/bookings | required | Submit a booking request |
| GET | /api/bookings/mine | required | My booking requests |
| GET | /api/bookings/assigned | required | Bookings assigned to me (tutor) |
| PATCH | /api/bookings/:id/status | required | Update a booking's status |
| GET | /api/tutors | — | List approved tutors (filterable) |
| POST | /api/tutors/apply | required, multipart | Apply to become a tutor |
| GET | /api/tutors/applications/mine | required | My application status |
| GET | /api/tutors/applications | admin | All applications |
| PATCH | /api/tutors/applications/:id | admin | Approve/reject application |
| POST | /api/contact | optional | Submit contact/feedback |
| GET | /api/donations/payment-info | — | Get Telebirr/CBE details |
| POST | /api/donations | optional | Submit a donation w/ transaction ref |
| PATCH | /api/profile | required | Update profile fields |
| POST | /api/profile/change-password | required | Change password |

All `required` routes need `Authorization: Bearer <token>` header, where `<token>` comes from the signup/login response.

## Notes
- Telebirr and CBE both require merchant agreements for real API integration. The current donation flow shows payment instructions and captures a transaction reference for manual verification — swap in real API calls once merchant credentials are available.
- Uploaded tutor certificates are stored in `/uploads/certificates` and served at `/uploads/certificates/<filename>`. For production, consider moving this to cloud storage (e.g. Cloudinary, S3) since Render's free tier filesystem is not persistent across deploys.
