const express = require('express');
const { optionalAuth } = require('../middleware/auth');
const { getPaymentInfo, submitDonation } = require('../controllers/donationController');

const router = express.Router();

router.get('/payment-info', getPaymentInfo);
router.post('/', optionalAuth, submitDonation);

module.exports = router;
