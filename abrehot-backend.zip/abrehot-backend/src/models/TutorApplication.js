const mongoose = require('mongoose');

const tutorApplicationSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },

    fullName: { type: String, required: true },
    gender: String,
    dob: Date,
    phone: { type: String, required: true },
    email: { type: String, required: true },

    education: String,
    institution: String,
    experience: String,
    certificateUrl: String,

    subjects: [String],
    grades: [String],
    languages: [String],
    mode: { type: String, enum: ['Online', 'In-Person', 'Both'] },

    city: { type: String, required: true },
    address: String,
    price: Number,
    availability: String,
    bio: String,

    status: {
      type: String,
      enum: ['pending', 'approved', 'rejected'],
      default: 'pending',
    },
    reviewNotes: String,
  },
  { timestamps: true }
);

module.exports = mongoose.model('TutorApplication', tutorApplicationSchema);
