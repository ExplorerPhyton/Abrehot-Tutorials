const TutorApplication = require('../models/TutorApplication');
const User = require('../models/User');

// POST /api/tutors/apply  (becomeatutor.html form, multipart with certificate file)
async function applyAsTutor(req, res) {
  try {
    const {
      fullName, gender, dob, phone, email,
      education, institution, experience,
      subject, grade, language, mode,
      city, address, price, availability, bio,
    } = req.body;

    if (!fullName || !phone || !email || !city) {
      return res.status(400).json({ message: 'Full name, phone, email, and city are required.' });
    }

    const certificateUrl = req.file ? `/uploads/certificates/${req.file.filename}` : undefined;

    const application = await TutorApplication.create({
      user: req.user._id,
      fullName, gender, dob, phone, email,
      education, institution, experience,
      certificateUrl,
      subjects: Array.isArray(subject) ? subject : subject ? [subject] : [],
      grades: Array.isArray(grade) ? grade : grade ? [grade] : [],
      languages: Array.isArray(language) ? language : language ? [language] : [],
      mode, city, address,
      price: price ? Number(price) : undefined,
      availability, bio,
    });

    res.status(201).json({ message: 'Application submitted for review.', application });
  } catch (err) {
    res.status(500).json({ message: 'Could not submit application.', error: err.message });
  }
}

// GET /api/tutors/applications/mine
async function getMyApplication(req, res) {
  const application = await TutorApplication.findOne({ user: req.user._id }).sort('-createdAt');
  res.json({ application });
}

// GET /api/tutors/applications (Admin only - review queue)
async function getAllApplications(req, res) {
  const applications = await TutorApplication.find().sort('-createdAt');
  res.json({ applications });
}

// PATCH /api/tutors/applications/:id (Admin only - approve/reject)
async function reviewApplication(req, res) {
  try {
    const { status, reviewNotes } = req.body;
    if (!['approved', 'rejected'].includes(status)) {
      return res.status(400).json({ message: 'Status must be approved or rejected.' });
    }

    const application = await TutorApplication.findById(req.params.id);
    if (!application) return res.status(404).json({ message: 'Application not found.' });

    application.status = status;
    application.reviewNotes = reviewNotes;
    await application.save();

    if (status === 'approved') {
      await User.findByIdAndUpdate(application.user, {
        role: 'Tutor',
        'tutorProfile.approved': true,
        'tutorProfile.subjects': application.subjects,
        'tutorProfile.grades': application.grades,
        'tutorProfile.languages': application.languages,
        'tutorProfile.mode': application.mode,
        'tutorProfile.city': application.city,
        'tutorProfile.address': application.address,
        'tutorProfile.price': application.price,
        'tutorProfile.bio': application.bio,
        'tutorProfile.availability': application.availability,
        'tutorProfile.certificateUrl': application.certificateUrl,
      });
    }

    res.json({ message: `Application ${status}.`, application });
  } catch (err) {
    res.status(500).json({ message: 'Could not review application.', error: err.message });
  }
}

// GET /api/tutors  (public listing for tutors.html)
async function listApprovedTutors(req, res) {
  const { subject, grade, city, mode } = req.query;

  const filter = { role: 'Tutor', 'tutorProfile.approved': true };
  if (subject) filter['tutorProfile.subjects'] = subject;
  if (grade) filter['tutorProfile.grades'] = grade;
  if (city) filter['tutorProfile.city'] = new RegExp(city, 'i');
  if (mode) filter['tutorProfile.mode'] = mode;

  const tutors = await User.find(filter).select(
    'fullName profilePicture tutorProfile'
  );
  res.json({ tutors });
}

module.exports = {
  applyAsTutor,
  getMyApplication,
  getAllApplications,
  reviewApplication,
  listApprovedTutors,
};
